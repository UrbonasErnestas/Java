import java.util.Scanner;

//class Fraction {
//    private int e, d;
//
//    void setFraction(int s, int v){
//        e = s;
//        d = v;
//    }
//    void print(){
//        System.out.println("e / d -> " + e / d);
//    }
//}
class Price {
    private int eur, ct;

    public void set(int e, int c) {
        this.eur = e;
        this.ct = c;
    }

    public int getEur() {
        return eur;
    }

    public int getCt() {
        return ct;
    }

    public void print() {
        System.out.print(eur + ".");
        if (ct < 10) {
            System.out.print("0");
        }
        System.out.println(ct);
    }
}

class OperatingSystem {
    private String name;
    private Price price = new Price();

    public void set(String name, Price price) {
        this.name = name;
        this.price = price;
    }

    public void print() {
        System.out.print("Operating System Name: " + name + " / ");
        price.print();
    }
}
class Computer{
    private String name;
    private Price price = new Price();
    OperatingSystem operatingSystem = new OperatingSystem();

    public void set(String computerName, Price computerPrice, String osName, Price osPrice){
        this.name = computerName;
        this.price = computerPrice;
        operatingSystem.set(osName,osPrice);
    }
    public void print(){
        System.out.println("Computer: " + name + " / ");
        price.print();
        operatingSystem.print();
//        System.out.println("Total price: " + );
    }
}


public class Main {
    public static void main(String[] args) {
//        Fraction a = new Fraction();
//        a.setFraction(10,2);
//        a.print();

        Price pcPrice = new Price();
        pcPrice.set(567, 30);
        Price osPrice = new Price();
        osPrice.set(123, 4);
        Computer computer = new Computer();
        computer.set("DELL", pcPrice, "Windows", osPrice);
        computer.print();



    }
}